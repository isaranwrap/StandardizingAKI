test_that("toy dataset loads properly", {
  expect_identical(toy$creat[1], 1.05)
})
