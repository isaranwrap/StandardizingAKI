library("VennDiagram")

dataPath <- "~/Desktop/toydata/toy.txt"
inputDataFrame <- data.frame(read.csv(dataPath, sep = "\t"))
# aki <- returnAKIpatients(setDT(inputDataFrame))
#
